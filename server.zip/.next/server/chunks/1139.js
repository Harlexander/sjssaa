"use strict";
exports.id = 1139;
exports.ids = [1139];
exports.modules = {

/***/ 6514:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4563);
/* harmony import */ var _fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7197);
/* harmony import */ var _fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_1__]);
_fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const ExecutiveContainer = ({ name , position , bio , mail , img  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "md:grid grid-cols-12 gap-10 space-y-5 md:space-y-0",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "col-span-3",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    src: img,
                    className: "h-60 w-60 object-cover mx-auto rounded-lg md:rounded-full"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "md:text-left text-center col-span-9 flex-col flex space-y-2 justify-center",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "font-primary text-3xl capitalize",
                        children: name
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                        className: "flex gap-4 justify-center md:justify-start items-center font-nunito uppercase",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_2__.FontAwesomeIcon, {
                                className: "text-sm text-[#800000] hidden md:block",
                                icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_1__.faUserTie
                            }),
                            " ",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: position
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "font-nunito",
                        children: bio
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ExecutiveContainer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1139:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "executiveData": () => (/* binding */ executiveData)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_Excos_ExecutiveContainer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6514);
/* harmony import */ var _components_Header_PageHeader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3814);
/* harmony import */ var _components_Header_UnderConstruction__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1168);
/* harmony import */ var _components_Navbar_Navbar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8395);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Excos_ExecutiveContainer__WEBPACK_IMPORTED_MODULE_2__, _components_Header_UnderConstruction__WEBPACK_IMPORTED_MODULE_4__]);
([_components_Excos_ExecutiveContainer__WEBPACK_IMPORTED_MODULE_2__, _components_Header_UnderConstruction__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const executiveData = [
    {
        name: "Kolawole Banire",
        img: "/president.jpg",
        bio: "I am interested in rendering service for our great school first or with the first; I believe my experience coupled with my interpersonal abilities would make me a strong fit for this position.",
        mail: "kolawole.banire@sjssaa.com",
        position: "President"
    },
    {
        name: "Israel Olusegun Alika",
        img: "../general secretary.png",
        bio: "A team work aim to design, build and develop the association for the progress, fairness, justice and benefits of all SJSSA members.",
        mail: "lanreare@sjssaa.com",
        position: "Vice President Nigeria"
    },
    {
        name: "Jacob Babatunde Ajayi",
        img: "../vp.png",
        bio: "I am an outstanding team player and possess good communication skills. I am hardworking, very well organized, and self-confident.",
        mail: "jb.ajayi@sjssaa.com",
        position: "Vice President Europe and Asia"
    },
    {
        name: "Solomon Oyedeji",
        img: "/vp-america.jpg",
        bio: "Passion to serve SJSSAA",
        mail: "oorekoya@sjssaa.com",
        position: "Vice President America"
    },
    {
        name: "Monday Udo",
        img: "/general.sec.jpg",
        bio: "",
        mail: "israelolusegun.alika@sjssaa.com",
        position: "General Secretary"
    },
    {
        name: "Dr. Emmanuel Ehiwe",
        img: "../asst.sec.europe & asia.png",
        bio: "Passion to serve SJSSAA",
        mail: "eehiwe@sjssaa.com",
        position: "Asst. Sect Europe and Asia"
    },
    {
        name: "Anthony Ebhojaye",
        img: "/asst.sec.north.jpg",
        bio: "Passion to serve SJSSAA",
        mail: "anthony.ebhojaye@sjssaa.com",
        position: "Asst. Sect North and South America"
    },
    {
        name: "Akeem Ajayi",
        img: "../financial secretary.png",
        bio: "I am an Accountant by training and I have also worked in the banking sector for 19 years. I am honest, hardworking and trustworthy and can be relied upon to do what is expected of me every-time",
        mail: "akeem.ajayi@sjssaa.com",
        position: "Financial Secretary"
    },
    {
        name: "Edward Dunkwu",
        img: "../treasurer.png",
        bio: "Passion to serve SJSSAA",
        mail: "edunkwu@sjssaa.com",
        position: "Treasurer"
    },
    {
        name: "Olanrewaju Dossouyovo",
        img: "/social.sect.jpg",
        bio: "Passion to serve SJSSAA",
        mail: "ola.dossouyovo@sjssaa.com",
        position: "Social Secretary"
    },
    {
        name: "Fatiu Bello Olaitan",
        img: "../assistant pro.png",
        bio: "Passion to serve SJSSAA",
        mail: "fatiu.bello@sjssaa.com",
        position: "Public Relations Officer"
    },
    {
        name: "Jolaosho Adewale",
        img: "/asst.fin.jpg",
        bio: "Passion to serve SJSSAA",
        mail: "jolaoshoadewale@sjssaa.com",
        position: "Asst. Fin. Secretary"
    },
    {
        name: "Samuel Afekhade",
        img: "/asst.social.jpg",
        bio: "Passion to serve SJSSAA",
        mail: "samuel.afe@sjssaa.com",
        position: "Asst. Social Secretary"
    },
    {
        name: "Aboyewa Okonedo",
        img: "",
        bio: "Passion to serve SJSSAA",
        mail: "aboyewa.okonedo@sjssaa.com",
        position: "Asst. General Secretary"
    }, 
];
const Index = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "bg-yellow-200 min-h-screen",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Navbar_Navbar__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Header_PageHeader__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                title: "National Executives"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-full md:px-32 px-5 space-y-12 py-20",
                children: executiveData.map((executive, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Excos_ExecutiveContainer__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                name: executive.name,
                                img: executive.img ? executive.img : "/user.webp",
                                bio: executive.bio,
                                mail: executive.mail,
                                position: executive.position
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "h-[0.1px] md:h-[0.5px] bg-yellow-900 bg-opacity-20"
                            })
                        ]
                    }))
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Index);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;