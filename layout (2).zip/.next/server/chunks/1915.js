"use strict";
exports.id = 1915;
exports.ids = [1915];
exports.modules = {

/***/ 1915:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ User)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_Sidebar_Sidebar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2275);
/* harmony import */ var _components_DashboardHeader_DashboardHeader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5316);
/* harmony import */ var _heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(467);
/* harmony import */ var _fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7197);
/* harmony import */ var _fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4563);
/* harmony import */ var _lib_user__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3460);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1185);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _lib_axios__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5007);
/* harmony import */ var _lib_payment__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2583);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Sidebar_Sidebar__WEBPACK_IMPORTED_MODULE_2__, _components_DashboardHeader_DashboardHeader__WEBPACK_IMPORTED_MODULE_3__, _heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_4__, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_6__, _lib_user__WEBPACK_IMPORTED_MODULE_7__, _headlessui_react__WEBPACK_IMPORTED_MODULE_8__, _lib_axios__WEBPACK_IMPORTED_MODULE_11__, _lib_payment__WEBPACK_IMPORTED_MODULE_12__]);
([_components_Sidebar_Sidebar__WEBPACK_IMPORTED_MODULE_2__, _components_DashboardHeader_DashboardHeader__WEBPACK_IMPORTED_MODULE_3__, _heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_4__, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_6__, _lib_user__WEBPACK_IMPORTED_MODULE_7__, _headlessui_react__WEBPACK_IMPORTED_MODULE_8__, _lib_axios__WEBPACK_IMPORTED_MODULE_11__, _lib_payment__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);













const user = {
    name: "Tom Cook",
    email: "tom@example.com",
    imageUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
};
const navigation = [
    {
        name: "Overview",
        href: "/dashboard",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_5__.FontAwesomeIcon, {
            icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_6__.faHomeAlt
        }),
        current: true
    },
    {
        name: "Members",
        href: "/dashboard/members",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_5__.FontAwesomeIcon, {
            icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_6__.faUserGroup
        }),
        current: true
    },
    {
        name: "Subscriptions",
        href: "/dashboard/dues",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_5__.FontAwesomeIcon, {
            icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_6__.faMoneyCheckDollar
        }),
        current: true
    },
    {
        name: "Events",
        href: "/dashboard/events",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_5__.FontAwesomeIcon, {
            icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_6__.faCalendarDays
        }),
        current: true
    },
    {
        name: "News and Updates",
        href: "/dashboard/news",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_5__.FontAwesomeIcon, {
            icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_6__.faNewspaper
        }),
        current: true
    },
    {
        name: "Job Board",
        href: "/dashboard/job-board",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_5__.FontAwesomeIcon, {
            icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_6__.faUserDoctor
        }),
        current: true
    }, 
];
const userNavigation = [
    {
        name: "Profile",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_5__.FontAwesomeIcon, {
            icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_6__.faUserAlt
        }),
        href: "/dashboard/profile"
    }
];
function MyModal() {
    const { token  } = (0,_lib_user__WEBPACK_IMPORTED_MODULE_7__/* .useUser */ .a)();
    const { query: { reference  }  } = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    const initiate = (0,react_query__WEBPACK_IMPORTED_MODULE_10__.useMutation)(async (data)=>await (0,_lib_payment__WEBPACK_IMPORTED_MODULE_12__/* .initiatePayment */ .e)(data, token), {
        onSuccess: ({ authorization_url  })=>window.location.href = authorization_url
    });
    const verify = (0,react_query__WEBPACK_IMPORTED_MODULE_10__.useQuery)([
        "verify_due"
    ], async ()=>await (0,_lib_payment__WEBPACK_IMPORTED_MODULE_12__/* .verifyPayment */ .m)(token, reference), {
        enabled: token !== null && reference !== undefined
    });
    let { 0: isOpen , 1: setIsOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(false);
    const body = {
        amount: 16000,
        purpose: "due",
        callback_url: "http://localhost:3000/dashboard/members",
        payment_id: "sjssaa"
    };
    const status = (0,react_query__WEBPACK_IMPORTED_MODULE_10__.useQuery)([
        "due_status"
    ], async ()=>{
        const { data  } = await _lib_axios__WEBPACK_IMPORTED_MODULE_11__/* .api.get */ .h.get("/due-status", {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        return data;
    }, {
        enabled: token !== null,
        onSuccess: (data)=>!data && setIsOpen(true),
        retry: 0
    });
    function closeModal() {
        setIsOpen(true);
    }
    console.log(status, verify, initiate);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_8__.Transition, {
            appear: true,
            show: isOpen,
            as: react__WEBPACK_IMPORTED_MODULE_9__.Fragment,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_headlessui_react__WEBPACK_IMPORTED_MODULE_8__.Dialog, {
                as: "div",
                className: "relative z-10",
                onClose: closeModal,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_8__.Transition.Child, {
                        as: react__WEBPACK_IMPORTED_MODULE_9__.Fragment,
                        enter: "ease-out duration-300",
                        enterFrom: "opacity-0",
                        enterTo: "opacity-100",
                        leave: "ease-in duration-200",
                        leaveFrom: "opacity-100",
                        leaveTo: "opacity-0",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "fixed inset-0 bg-black bg-opacity-25"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "fixed inset-0 overflow-y-auto",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "flex min-h-full items-center justify-center p-4 text-center",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_8__.Transition.Child, {
                                as: react__WEBPACK_IMPORTED_MODULE_9__.Fragment,
                                enter: "ease-out duration-300",
                                enterFrom: "opacity-0 scale-95",
                                enterTo: "opacity-100 scale-100",
                                leave: "ease-in duration-200",
                                leaveFrom: "opacity-100 scale-100",
                                leaveTo: "opacity-0 scale-95",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_headlessui_react__WEBPACK_IMPORTED_MODULE_8__.Dialog.Panel, {
                                    className: "w-full max-w-md transform overflow-hidden rounded-2xl bg-white p-6 text-left align-middle shadow-xl transition-all",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_headlessui_react__WEBPACK_IMPORTED_MODULE_8__.Dialog.Title, {
                                            as: "h3",
                                            className: "text-lg font-medium leading-6 text-gray-900 font-figtree",
                                            children: [
                                                verify.isIdle && "Annual Due Payment",
                                                verify.isSuccess && "Payment Sucessful!",
                                                verify.isLoading && "Please Wait!"
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "mt-2",
                                            children: [
                                                verify.isIdle && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "text-sm font-figtree text-gray-500",
                                                    children: "Your annual due of N16,000.00 is neccessary for continuation of usage of this platform. Click the button and you will be redirected to a secured payment page."
                                                }),
                                                verify.isSuccess && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "text-sm text-center font-figtree text-gray-500",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_4__.CheckBadgeIcon, {
                                                        className: "h-28 mx-auto text-green-500"
                                                    })
                                                }),
                                                verify.isLoading && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "flex",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_5__.FontAwesomeIcon, {
                                                        icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_6__.faSpinner,
                                                        spin: true,
                                                        className: "text-pry text-5xl mx-auto"
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "mt-4",
                                            children: [
                                                verify.isIdle && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    type: "button",
                                                    className: "inline-flex justify-center font-figtree rounded-md border border-transparent bg-blue-100 px-4 py-2 text-sm font-medium text-blue-900 hover:bg-blue-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2",
                                                    onClick: ()=>initiate.mutate(body),
                                                    children: initiate.isLoading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_5__.FontAwesomeIcon, {
                                                        icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_6__.faSpinner,
                                                        spin: true
                                                    }) : "Pay Now"
                                                }),
                                                verify.isSuccess && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    type: "button",
                                                    className: "inline-flex justify-center font-figtree rounded-md border border-transparent bg-blue-100 px-4 py-2 text-sm font-medium text-blue-900 hover:bg-blue-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2",
                                                    onClick: ()=>setIsOpen(false),
                                                    children: "Close"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            })
                        })
                    })
                ]
            })
        })
    });
}
function User({ children  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_lib_user__WEBPACK_IMPORTED_MODULE_7__/* .UserProvider */ .d, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "relative",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Sidebar_Sidebar__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    navigation: navigation,
                    userNavigation: userNavigation,
                    logo: "/logo.png"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(MyModal, {}),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "sidebar bg-gray-100 min-h-screen col-span-9 bg-blueGray-100",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_DashboardHeader_DashboardHeader__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                            userNavigation: userNavigation,
                            navigation: navigation
                        }),
                        children
                    ]
                })
            ]
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2583:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "e": () => (/* binding */ initiatePayment),
/* harmony export */   "m": () => (/* binding */ verifyPayment)
/* harmony export */ });
/* harmony import */ var _axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5007);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_axios__WEBPACK_IMPORTED_MODULE_0__]);
_axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const initiatePayment = async (body, token)=>{
    const { data  } = await _axios__WEBPACK_IMPORTED_MODULE_0__/* .api.post */ .h.post("/create-payment", body, {
        headers: {
            Authorization: `Bearer ${token}`
        }
    });
    return data;
};
const verifyPayment = async (token, reference)=>{
    const response = await _axios__WEBPACK_IMPORTED_MODULE_0__/* .api.get */ .h.get("/verify-payment", {
        headers: {
            Authorization: `Bearer ${token}`
        },
        params: {
            ref: reference
        }
    });
    return response.data;
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;