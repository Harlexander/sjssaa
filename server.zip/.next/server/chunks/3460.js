"use strict";
exports.id = 3460;
exports.ids = [3460];
exports.modules = {

/***/ 5007:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "h": () => (/* binding */ api)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const api = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
    baseURL: "http://localhost:8000/api"
}); // export const api = axios.create({ baseURL : "https://api.sjssaa.com/api"});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3460:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "a": () => (/* binding */ useUser),
/* harmony export */   "d": () => (/* binding */ UserProvider)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _axios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5007);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_axios__WEBPACK_IMPORTED_MODULE_3__]);
_axios__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const Context = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)();
const useUser = ()=>(0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(Context);
const UserProvider = ({ children  })=>{
    const { 0: token , 1: setToken  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: tokenExpired , 1: setTokenExpired  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const user = (0,react_query__WEBPACK_IMPORTED_MODULE_2__.useQuery)(`${token}`, async ()=>{
        const { data  } = await _axios__WEBPACK_IMPORTED_MODULE_3__/* .api.get */ .h.get("/user", {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        return data;
    }, {
        enabled: token !== null,
        retry: 1
    });
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const key = window.localStorage.getItem("token");
        key && setToken(key);
        window.addEventListener("storage", (event)=>{
            const token = event.currentTarget.localStorage.token;
            if (token) {
                setToken(token);
            } else {
                setToken(null);
            }
        });
    }, []);
    const storeToken = (token)=>{
        window.localStorage.setItem("token", token);
        window.dispatchEvent(new Event("storage"));
        router.push("/dashboard");
    };
    // useEffect(() => {
    //   if(user.error){
    //     if(user.error && user.error.response.data.message === "Unauthenticated."){
    //         setTokenExpired(true);
    //         user.remove();
    //     }
    //   }
    // }, [user]);
    const signOut = async (navigate)=>{
        await _axios__WEBPACK_IMPORTED_MODULE_3__/* .api.post */ .h.post("/logout", {}, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        user.remove();
        localStorage.removeItem("token");
        router.push("/login");
    };
    const data = {
        user: user.data || {},
        loading: user.isLoading,
        signOut,
        token,
        tokenExpired,
        setTokenExpired,
        storeToken,
        refetch: user.refetch
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Context.Provider, {
        value: data,
        children: children
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;