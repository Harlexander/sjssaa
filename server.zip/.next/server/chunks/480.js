"use strict";
exports.id = 480;
exports.ids = [480];
exports.modules = {

/***/ 8438:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(467);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _lib_imgHost__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4105);
/* harmony import */ var moment_moment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3332);
/* harmony import */ var moment_moment__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(moment_moment__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_1__]);
_heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const NewsCard = ({ admin , title , content , image , name , created_at , id , deleteNews  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "bg-white rounded-lg shadow flex-col flex",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                src: _lib_imgHost__WEBPACK_IMPORTED_MODULE_4__/* .imgHost */ .H + image,
                alt: "",
                className: "rounded-t-lg w-full h-64 object-cover"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "p-4 rounded z-20 grow flex flex-col gap-5",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "font-manrope font-semibold text-lg",
                        children: title
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex items-center gap-4",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "font-figtree text-xs flex items-center gap-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_1__.CalendarDaysIcon, {
                                        className: "h-4 text-yellow-400"
                                    }),
                                    moment_moment__WEBPACK_IMPORTED_MODULE_3___default()(created_at).format("DD MMMM, YYYY")
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "font-figtree text-xs flex items-center gap-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_1__.UserIcon, {
                                        className: "h-4 text-yellow-400"
                                    }),
                                    name
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                        className: "font-figtree whitespace-pre-line text-sm",
                        children: [
                            content.slice(0, 250),
                            "..."
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex items-center gap-4 text-white",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: "font-figtree text-sm px-6 bg-yellow-500 py-1.5 rounded",
                                children: "View All"
                            }),
                            admin && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                onClick: deleteNews,
                                className: "font-figtree text-sm bg-red-500 px-6 py-1.5 rounded",
                                children: "Delete"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NewsCard);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4105:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "H": () => (/* binding */ imgHost)
/* harmony export */ });
const imgHost = "https://api.sjssaa.com/public/storage/"; // export const imgHost = "http://localhost:8000/storage/";


/***/ }),

/***/ 7302:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "v": () => (/* binding */ handleUpload)
/* harmony export */ });
/* harmony import */ var _axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5007);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_axios__WEBPACK_IMPORTED_MODULE_0__]);
_axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const handleUpload = async (file)=>{
    try {
        const formData = new FormData();
        formData.append("file", file);
        const { data  } = await _axios__WEBPACK_IMPORTED_MODULE_0__/* .api.post */ .h.post("/upload-file", formData);
        return data;
    } catch (error) {
        throw Error("Image is required!");
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 480:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NewsButton": () => (/* binding */ NewsButton),
/* harmony export */   "NewsForm": () => (/* binding */ NewsForm),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _layout_users__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1915);
/* harmony import */ var _components_Cards_NewsCard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8438);
/* harmony import */ var _components_Header_DashboardTitle__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4658);
/* harmony import */ var _components_Modal_Modal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1836);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _lib_axios__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5007);
/* harmony import */ var _lib_user__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3460);
/* harmony import */ var _heroicons_react_24_solid__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(291);
/* harmony import */ var _lib_uploadImg__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7302);
/* harmony import */ var react_spinners__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8176);
/* harmony import */ var react_spinners__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_spinners__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _components_Badge_BadgeSuccess__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(8626);
/* harmony import */ var react_loading_skeleton__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(4275);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_layout_users__WEBPACK_IMPORTED_MODULE_2__, _components_Cards_NewsCard__WEBPACK_IMPORTED_MODULE_3__, _components_Header_DashboardTitle__WEBPACK_IMPORTED_MODULE_4__, _components_Modal_Modal__WEBPACK_IMPORTED_MODULE_5__, _lib_axios__WEBPACK_IMPORTED_MODULE_7__, _lib_user__WEBPACK_IMPORTED_MODULE_8__, _heroicons_react_24_solid__WEBPACK_IMPORTED_MODULE_9__, _lib_uploadImg__WEBPACK_IMPORTED_MODULE_10__, _components_Badge_BadgeSuccess__WEBPACK_IMPORTED_MODULE_12__, react_loading_skeleton__WEBPACK_IMPORTED_MODULE_13__]);
([_layout_users__WEBPACK_IMPORTED_MODULE_2__, _components_Cards_NewsCard__WEBPACK_IMPORTED_MODULE_3__, _components_Header_DashboardTitle__WEBPACK_IMPORTED_MODULE_4__, _components_Modal_Modal__WEBPACK_IMPORTED_MODULE_5__, _lib_axios__WEBPACK_IMPORTED_MODULE_7__, _lib_user__WEBPACK_IMPORTED_MODULE_8__, _heroicons_react_24_solid__WEBPACK_IMPORTED_MODULE_9__, _lib_uploadImg__WEBPACK_IMPORTED_MODULE_10__, _components_Badge_BadgeSuccess__WEBPACK_IMPORTED_MODULE_12__, react_loading_skeleton__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);














const Index = ()=>{
    const { token  } = (0,_lib_user__WEBPACK_IMPORTED_MODULE_8__/* .useUser */ .a)();
    const { 0: isOpen , 1: setIsOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const closeModal = ()=>setIsOpen(!isOpen);
    const { 0: formValues , 1: setFormValues  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        title: "",
        content: ""
    });
    const handleChange = (e)=>{
        const { name , value  } = e.target;
        setFormValues((prevValues)=>({
                ...prevValues,
                [name]: value
            }));
    };
    function handleImageChange(event) {
        setFormValues((prevValues)=>({
                ...prevValues,
                "image": event.target.files[0]
            }));
        console.log(event.target.files[0]);
    }
    const handleSubmit = (e)=>{
        mutate(formValues); // You can perform any action with the form values here, such as sending a request to an API or updating the state of a parent component.
    };
    const news = (0,react_query__WEBPACK_IMPORTED_MODULE_6__.useQuery)([
        "news"
    ], async ()=>{
        const { data  } = await _lib_axios__WEBPACK_IMPORTED_MODULE_7__/* .api.get */ .h.get("/news", {
            headers: {
                Authorization: `Bearer ${token} `
            }
        });
        return data;
    }, {
        enabled: token !== null
    });
    console.log(news.data);
    const { isLoading , mutate , data , error , isSuccess  } = (0,react_query__WEBPACK_IMPORTED_MODULE_6__.useMutation)(async (values)=>{
        const img_url = await (0,_lib_uploadImg__WEBPACK_IMPORTED_MODULE_10__/* .handleUpload */ .v)(values.image);
        const { data  } = await _lib_axios__WEBPACK_IMPORTED_MODULE_7__/* .api.post */ .h.post("/news", {
            ...values,
            image: img_url
        }, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        return data;
    }, {
        onSuccess: ()=>{
            news.refetch();
        }
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_layout_users__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Modal_Modal__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                isOpen: isOpen,
                title: "Post News",
                body: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(NewsForm, {
                    handleChange: handleChange,
                    formValues: formValues,
                    handleImageChange: handleImageChange,
                    isSuccess: isSuccess
                }),
                button: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(NewsButton, {
                    handleSubmit: handleSubmit,
                    isLoading: isLoading
                }),
                closeModal: closeModal
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
                className: "md:p-10 p-5 space-y-8",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Header_DashboardTitle__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                        title: "News and Updates",
                        subtitle: "Activities and News relating to the association.",
                        value: "Post News",
                        onClick: closeModal
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                        className: "grid sm:grid-cols-3 gap-4",
                        children: [
                            news.isSuccess && news.data.map(({ title , content , created_at , image , member: { firstName , lastName  } , index  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Cards_NewsCard__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                    title: title,
                                    content: content,
                                    image: image,
                                    name: firstName + " " + lastName,
                                    created_at: created_at
                                }, index)),
                            news.isSuccess && news.data.length < 1 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "bg-white h-[80vh] w-full col-span-3 flex items-center justify-center rounded-xl",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "space-y-2",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "font-figtree text-center text-2xl font-bold",
                                            children: "No News Update"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "font-figtree mx-auto text-center text-sm sm:w-2/3",
                                            children: "Post news update for members on ongoing situations of the association, school, country and other related topics to the association"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            onClick: closeModal,
                                            className: "flex mx-auto items-center whitespace-nowrap text-sm sm:text-md gap-1.5 sm:gap-3 font-manrope bg-yellow-400 px-4 sm:px-12 py-2 sm:py-2 rounded shadow-xl text-white",
                                            children: "Post News"
                                        })
                                    ]
                                })
                            }),
                            news.isLoading && Array(3).fill("").map((indexes, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "bg-white shadow-lg p-4 rounded-lg",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_loading_skeleton__WEBPACK_IMPORTED_MODULE_13__["default"], {
                                            className: "h-40"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_loading_skeleton__WEBPACK_IMPORTED_MODULE_13__["default"], {}),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_loading_skeleton__WEBPACK_IMPORTED_MODULE_13__["default"], {
                                            className: "h-20"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_loading_skeleton__WEBPACK_IMPORTED_MODULE_13__["default"], {
                                            className: "h-10"
                                        })
                                    ]
                                }, index))
                        ]
                    })
                ]
            })
        ]
    });
};
const NewsButton = ({ handleSubmit , isLoading  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
        onClick: handleSubmit,
        type: "button",
        className: "inline-flex text-white font-figtree justify-center rounded-md border border-transparent bg-pry px-4 py-2 text-sm font-medium hover:bg-yellow-800 focus:outline-none focus-visible:ring-2 focus-visible:ring-pry focus-visible:ring-offset-2",
        children: isLoading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_spinners__WEBPACK_IMPORTED_MODULE_11__.ScaleLoader, {
            className: "px-8",
            color: "white",
            height: 16
        }) : "Upload News"
    });
const NewsForm = ({ handleChange , formValues , handleImageChange , isSuccess  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "space-y-5 py-5",
        children: [
            isSuccess && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Badge_BadgeSuccess__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                message: "News Uploaded Successful. Thank You!"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "font-figtree",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                    type: "text",
                    id: "title",
                    name: "title",
                    required: true,
                    value: formValues.title,
                    onChange: handleChange,
                    className: "border-b-2 font-figtree focus:ring-0 focus:border-b-2 focus:border-pry border-pry border-0 w-full",
                    placeholder: "Title"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                    id: "content",
                    name: "content",
                    required: true,
                    value: formValues.content,
                    onChange: handleChange,
                    className: "border-b-2 font-figtree focus:ring-0 focus:border-b-2 focus:border-pry border-pry border-0 w-full",
                    placeholder: "Content",
                    rows: 5
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "space-y-3 text-center border items-center border-pry rounded-xl flex flex-col justify-center p-5",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_heroicons_react_24_solid__WEBPACK_IMPORTED_MODULE_9__.PhotoIcon, {
                        className: "h-10 text-pry"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            children: "Upload Image"
                        })
                    }),
                    formValues.image && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex flex-wrap gap-1",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            src: URL.createObjectURL(formValues.image),
                            alt: "img",
                            className: "w-full object-cover"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "relative",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                required: true,
                                type: "file",
                                name: "image",
                                onChange: handleImageChange,
                                className: "h-full w-full opacity-0 absolute"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: "bg-pry py-2 font-figtree px-6 rounded-xl text-white",
                                children: "Select Image"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Index);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;