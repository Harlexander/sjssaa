"use strict";
exports.id = 8395;
exports.ids = [8395];
exports.modules = {

/***/ 3664:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "f": () => (/* binding */ OutlineButton),
/* harmony export */   "g": () => (/* binding */ SolidButton)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



const OutlineButton = ({ title , href ="" , additionalClass  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
        href: href,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
            className: `border-2 border-[#E8A902] hover:bg-pry hover:text-white px-8 py-1 text-pry ${additionalClass}`,
            children: title
        })
    });
};
const SolidButton = ({ href ="" , onClick , title , additionalClass  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
        href: href,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
            onClick: onClick,
            className: `bg-pry  px-8 py-1 text-white ${additionalClass}`,
            children: title
        })
    });
};


/***/ }),

/***/ 8395:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var flowbite_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7532);
/* harmony import */ var flowbite_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(flowbite_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _Button_Button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3664);





const IndexNavbar = ()=>{
    const routes = [
        {
            title: "HOME",
            link: "/"
        },
        {
            title: "ABOUT US",
            sublinks: [
                {
                    title: "About SJSSAA",
                    link: "/about"
                },
                {
                    title: "Our Mission and Vision",
                    link: "/mission-vision"
                },
                {
                    title: "Strategic Plan",
                    link: "./strategic-plan.pdf"
                }
            ]
        },
        {
            title: "GALLERY",
            link: "/gallery"
        },
        {
            title: "EVENTS",
            link: "/#events"
        },
        {
            title: "EXCOS",
            sublinks: [
                {
                    title: "National Executives",
                    link: "/excos/national-executives"
                },
                {
                    title: "Board of Trustees",
                    link: "/excos/board-of-trustees"
                },
                {
                    title: "Set Representatives",
                    link: "/excos/set-representative"
                },
                {
                    title: "Director of Membership",
                    link: "/excos/web-master"
                }, 
            ]
        },
        {
            title: "MEMBERS",
            link: "/members"
        },
        {
            title: "CONTACT",
            link: "/contact"
        },
        {
            title: "EMAIL",
            link: "https://premium262.web-hosting.com:2096/"
        }, 
    ];
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(flowbite_react__WEBPACK_IMPORTED_MODULE_1__.Navbar, {
        fluid: true,
        style: {
            zIndex: "1",
            width: "100%",
            background: "white"
        },
        rounded: true,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(flowbite_react__WEBPACK_IMPORTED_MODULE_1__.Navbar.Brand, {
                href: "/",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: "/logo.jfif",
                        className: "mr-3 h-16 sm:h-13",
                        alt: "Flowbite Logo"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: "/logo-1.jfif",
                        className: "mr-3 h-16 sm:h-13",
                        alt: "Flowbite Logo"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex md:order-2 my-3",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Button_Button__WEBPACK_IMPORTED_MODULE_4__/* .OutlineButton */ .f, {
                        href: "/login",
                        title: "Sign In"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(flowbite_react__WEBPACK_IMPORTED_MODULE_1__.Navbar.Toggle, {})
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(flowbite_react__WEBPACK_IMPORTED_MODULE_1__.Navbar.Collapse, {
                children: routes.map((item, index)=>{
                    if (item.title === "EXCOS" || item.title === "ABOUT US") {
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(NavDropdown, {
                            label: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(flowbite_react__WEBPACK_IMPORTED_MODULE_1__.Navbar.Link, {
                                href: item.link,
                                style: {
                                    fontFamily: "Montserrat"
                                },
                                children: item.title
                            }),
                            sublinks: item.sublinks
                        }, index);
                    } else {
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(flowbite_react__WEBPACK_IMPORTED_MODULE_1__.Navbar.Link, {
                            href: item.link,
                            style: {
                                fontFamily: "Montserrat"
                            },
                            children: item.title
                        }, index);
                    }
                })
            })
        ]
    });
};
const NavDropdown = ({ label , sublinks  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(flowbite_react__WEBPACK_IMPORTED_MODULE_1__.Dropdown, {
        arrowIcon: false,
        inline: true,
        label: label,
        style: {
            borderRadius: 0,
            fontFamily: "Montserrat"
        },
        children: sublinks.map(({ title , link  }, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(flowbite_react__WEBPACK_IMPORTED_MODULE_1__.Dropdown.Item, {
                style: {
                    fontFamily: "Montserrat"
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                    href: link,
                    children: title
                }, index)
            }, link))
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (IndexNavbar);


/***/ })

};
;