"use strict";
exports.id = 4996;
exports.ids = [4996];
exports.modules = {

/***/ 1963:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(467);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2245);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _Text_ReadMore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5805);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_1__]);
_heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const JobsCard = ({ admin , title , org , exp_date , created_at , description , contact , link  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "bg-white rounded flex flex-col justify-between p-4 gap-4 shadow",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "space-y-4",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "font-manrope font-semibold capitalize",
                        children: title
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "font-figtree",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                            className: "text-xs flex items-center gap-2",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_1__.BuildingOfficeIcon, {
                                    className: "h-4 text-yellow-500"
                                }),
                                " ",
                                org
                            ]
                        })
                    }),
                    admin && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "font-figtree",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                            className: "text-xs flex items-center gap-2",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_1__.UserIcon, {
                                    className: "h-4 text-yellow-500"
                                }),
                                "Dunkwu Alexander"
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "font-figtree space-y-1",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                            className: "text-xs",
                            children: [
                                "Posted: ",
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                    className: "font-semibold",
                                    children: [
                                        moment__WEBPACK_IMPORTED_MODULE_2___default().duration(moment__WEBPACK_IMPORTED_MODULE_2___default()().diff(created_at)).humanize(),
                                        " ago"
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "font-figtree space-y-1",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "text-xs font-semibold",
                                children: "Job Description: "
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "text-sm text-gray-800",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Text_ReadMore__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                    text: description,
                                    maxLength: 150
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "space-y-4",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "font-figtree space-y-1 flex items-center justify-between ",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("small", {
                                className: "text-xs font-semibold flex items-center gap-1",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_1__.CalendarDaysIcon, {
                                        className: "h-4 text-yellow-500"
                                    }),
                                    "  Closing Date"
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "text-xs flex items-center gap-2",
                                children: exp_date ? exp_date : "No date given"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex gap-4 items-center",
                        children: [
                            contact && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                href: link,
                                className: "font-figtree text-xs flex items-center justify-center gap-3 text-center bg-pry text-white w-full py-1.5 rounded-lg",
                                children: [
                                    "Apply ",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_1__.LinkIcon, {
                                        className: "h-4"
                                    })
                                ]
                            }),
                            contact && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                href: `mailto:${contact}`,
                                className: "font-figtree text-xs flex items-center justify-center gap-3 text-center border-2 border-pry text-pry w-full py-1 rounded-lg",
                                children: [
                                    "Contact ",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_1__.EnvelopeIcon, {
                                        className: "h-4"
                                    })
                                ]
                            }),
                            admin && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                className: "font-figtree text-xs flex items-center justify-center gap-3text-center bg-red-500 text-white w-full py-1 rounded-lg",
                                children: "Delete"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (JobsCard);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5805:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const ReadMore = ({ text , maxLength  })=>{
    const { 0: showFullText , 1: setShowFullText  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const toggleTextVisibility = ()=>{
        setShowFullText(!showFullText);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: showFullText ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
            className: "text-sm font-light",
            onClick: toggleTextVisibility,
            style: {
                whiteSpace: "pre-line"
            },
            children: text
        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
            className: "text-sm font-light",
            onClick: toggleTextVisibility,
            style: {
                whiteSpace: "pre-line"
            },
            children: [
                text.length > maxLength ? `${text.slice(0, maxLength)}... ` : text,
                " ",
                text.length > maxLength && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "text-blue-500 underline font-semibold font-figtree cursor-pointer",
                    children: "Read More"
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ReadMore);


/***/ }),

/***/ 5658:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C": () => (/* binding */ handleChange),
/* harmony export */   "y": () => (/* binding */ handleImageChange)
/* harmony export */ });
const handleChange = (e, setFormValues)=>{
    const { name , value  } = e.target;
    setFormValues((prevValues)=>({
            ...prevValues,
            [name]: value
        }));
};
function handleImageChange(event, setFormValues, name = "image") {
    setFormValues((prevValues)=>({
            ...prevValues,
            [name]: event.target.files[0]
        }));
}


/***/ }),

/***/ 4996:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "JobButton": () => (/* binding */ JobButton),
/* harmony export */   "JobForm": () => (/* binding */ JobForm),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _layout_users__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1915);
/* harmony import */ var _heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(467);
/* harmony import */ var _components_Cards_JobsCard__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1963);
/* harmony import */ var _components_Header_DashboardTitle__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4658);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _lib_axios__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5007);
/* harmony import */ var _lib_user__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3460);
/* harmony import */ var react_spinners__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8176);
/* harmony import */ var react_spinners__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_spinners__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_Modal_Modal__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1836);
/* harmony import */ var _lib_handleInput__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(5658);
/* harmony import */ var _components_Badge_BadgeSuccess__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8626);
/* harmony import */ var _lib_searchFunction__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(749);
/* harmony import */ var react_loading_skeleton__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(4275);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_layout_users__WEBPACK_IMPORTED_MODULE_2__, _heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_3__, _components_Cards_JobsCard__WEBPACK_IMPORTED_MODULE_4__, _components_Header_DashboardTitle__WEBPACK_IMPORTED_MODULE_5__, _lib_axios__WEBPACK_IMPORTED_MODULE_7__, _lib_user__WEBPACK_IMPORTED_MODULE_8__, _components_Modal_Modal__WEBPACK_IMPORTED_MODULE_10__, _components_Badge_BadgeSuccess__WEBPACK_IMPORTED_MODULE_11__, react_loading_skeleton__WEBPACK_IMPORTED_MODULE_12__]);
([_layout_users__WEBPACK_IMPORTED_MODULE_2__, _heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_3__, _components_Cards_JobsCard__WEBPACK_IMPORTED_MODULE_4__, _components_Header_DashboardTitle__WEBPACK_IMPORTED_MODULE_5__, _lib_axios__WEBPACK_IMPORTED_MODULE_7__, _lib_user__WEBPACK_IMPORTED_MODULE_8__, _components_Modal_Modal__WEBPACK_IMPORTED_MODULE_10__, _components_Badge_BadgeSuccess__WEBPACK_IMPORTED_MODULE_11__, react_loading_skeleton__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);















const Index = ()=>{
    const { token  } = (0,_lib_user__WEBPACK_IMPORTED_MODULE_8__/* .useUser */ .a)();
    const { 0: isOpen , 1: setIsOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: searchQuery , 1: setSearchQuery  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const { 0: searchResult , 1: setSearchResult  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const closeModal = ()=>setIsOpen(!isOpen);
    const { 0: formValues , 1: setFormValues  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        title: ""
    });
    const jobs = (0,react_query__WEBPACK_IMPORTED_MODULE_6__.useQuery)([
        "job-board"
    ], async ()=>{
        const { data  } = await _lib_axios__WEBPACK_IMPORTED_MODULE_7__/* .api.get */ .h.get("/job-board", {
            headers: {
                Authorization: `Bearer ${token} `
            }
        });
        return data;
    }, {
        enabled: token !== null
    });
    const { isLoading , mutate , isSuccess  } = (0,react_query__WEBPACK_IMPORTED_MODULE_6__.useMutation)(async (values)=>{
        const { data  } = await _lib_axios__WEBPACK_IMPORTED_MODULE_7__/* .api.post */ .h.post("/job-board", values, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        return data;
    }, {
        onSuccess: ()=>{
            jobs.refetch();
        }
    });
    const handleSubmit = ()=>{
        mutate(formValues);
    };
    console.log(formValues);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (searchQuery.length > 0) {
            const result = (0,_lib_searchFunction__WEBPACK_IMPORTED_MODULE_13__/* .searchByTitle */ .SJ)(searchQuery, jobs.data);
            setSearchResult(result);
        } else {
            setSearchResult([]);
        }
    }, [
        searchQuery
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_layout_users__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Modal_Modal__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                isOpen: isOpen,
                title: "Add Job Opening",
                body: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(JobForm, {
                    handleChange: (e)=>(0,_lib_handleInput__WEBPACK_IMPORTED_MODULE_14__/* .handleChange */ .C)(e, setFormValues),
                    formValues: formValues,
                    isSuccess: isSuccess
                }),
                button: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(JobButton, {
                    handleSubmit: handleSubmit,
                    isLoading: isLoading
                }),
                closeModal: closeModal
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
                className: "md:p-10 p-5 space-y-8",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Header_DashboardTitle__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        title: "Job Board",
                        subtitle: "Post job opportunies for members and also search for suitable opportunities.",
                        onClick: closeModal,
                        value: "Post Job"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                        className: "bg-white p-2 rounded",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "bg-gray-200 w-3/5 flex px-2 gap-2 items-center",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_3__.MagnifyingGlassIcon, {
                                    className: "h-4"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                    onChange: (e)=>setSearchQuery(e.target.value),
                                    className: "font-figtree bg-transparent w-full text-sm rounded px-2 py-1",
                                    placeholder: "Search"
                                })
                            ]
                        })
                    }),
                    searchResult.length > 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                        className: "space-y-5",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "space-y-1",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "font-figtree font-semibold",
                                        children: "Search Results"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                                        className: "grid sm:grid-cols-3 gap-3",
                                        children: searchResult.map(({ title , org , exp_date , created_at , description , contact , link  }, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Cards_JobsCard__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                title: title,
                                                org: org,
                                                exp_date: exp_date,
                                                created_at: created_at,
                                                contact: contact,
                                                link: link,
                                                description: description
                                            }, index))
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {})
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                        className: "grid sm:grid-cols-3 gap-5",
                        children: [
                            jobs.isSuccess && jobs.data.map(({ title , org , exp_date , created_at , description , contact , link  }, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Cards_JobsCard__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                    title: title,
                                    org: org,
                                    exp_date: exp_date,
                                    created_at: created_at,
                                    contact: contact,
                                    link: link,
                                    description: description
                                }, index)),
                            jobs.isSuccess && jobs.data.length < 1 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "bg-white h-[80vh] w-full col-span-3 flex items-center justify-center rounded-xl",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "space-y-2",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "font-figtree text-center text-2xl font-bold",
                                            children: "No Open Jobs"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "font-figtree mx-auto text-center text-sm sm:w-2/3",
                                            children: "Post job offers and opportunities for members of the association on any field or profession."
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            onClick: closeModal,
                                            className: "flex mx-auto items-center whitespace-nowrap text-sm sm:text-md gap-1.5 sm:gap-3 font-manrope bg-yellow-400 px-4 sm:px-12 py-2 sm:py-2 rounded shadow-xl text-white",
                                            children: "Post Job"
                                        })
                                    ]
                                })
                            }),
                            jobs.isLoading && Array(3).fill("").map((indexes, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "bg-white shadow-lg p-4 rounded-lg",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_loading_skeleton__WEBPACK_IMPORTED_MODULE_12__["default"], {
                                            className: "h-40"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_loading_skeleton__WEBPACK_IMPORTED_MODULE_12__["default"], {}),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_loading_skeleton__WEBPACK_IMPORTED_MODULE_12__["default"], {
                                            className: "h-20"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_loading_skeleton__WEBPACK_IMPORTED_MODULE_12__["default"], {
                                            className: "h-10"
                                        })
                                    ]
                                }, index))
                        ]
                    })
                ]
            })
        ]
    });
};
const JobButton = ({ handleSubmit , isLoading  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
        onClick: handleSubmit,
        type: "button",
        className: "inline-flex text-white font-figtree justify-center rounded-md border border-transparent bg-pry px-4 py-2 text-sm font-medium hover:bg-yellow-800 focus:outline-none focus-visible:ring-2 focus-visible:ring-pry focus-visible:ring-offset-2",
        children: isLoading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_spinners__WEBPACK_IMPORTED_MODULE_9__.ScaleLoader, {
            className: "px-8",
            color: "white",
            height: 16
        }) : "Upload Job"
    });
const JobForm = ({ handleChange , formValues , handleImageChange , isSuccess  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "space-y-5 py-5 font-figtree",
        children: [
            isSuccess && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Badge_BadgeSuccess__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                message: "Job created. Members will be notified!"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: "text-sm",
                children: "Upload job opening for members to apply and kindly add a registration or application link."
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "font-figtree",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                    type: "text",
                    name: "title",
                    required: true,
                    value: formValues.title,
                    onChange: handleChange,
                    className: "border-b-2 font-figtree focus:ring-0 focus:border-b-2 focus:border-pry border-pry border-0 w-full",
                    placeholder: "Job Title"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "font-figtree",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                    type: "text",
                    name: "org",
                    required: true,
                    value: formValues.org,
                    onChange: handleChange,
                    className: "border-b-2 font-figtree focus:ring-0 focus:border-b-2 focus:border-pry border-pry border-0 w-full",
                    placeholder: "Organisation"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "font-figtree",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                        type: "date",
                        name: "exp_date",
                        required: true,
                        value: formValues.date,
                        onChange: handleChange,
                        className: "border-b-2 font-figtree focus:ring-0 focus:border-b-2 focus:border-pry border-pry border-0 w-full",
                        placeholder: "Expiration Date"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                        className: "px-3",
                        children: "When would this offer be closed, if no expiration leave it blank"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "font-figtree",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                        type: "url",
                        name: "link",
                        required: true,
                        value: formValues.link,
                        onChange: handleChange,
                        className: "border-b-2 font-figtree focus:ring-0 focus:border-b-2 focus:border-pry border-pry border-0 w-full",
                        placeholder: "Application Link"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                        className: "px-3",
                        children: "Email address or application link is required"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "font-figtree",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                        type: "text",
                        name: "contact",
                        required: true,
                        value: formValues.contact,
                        onChange: handleChange,
                        className: "border-b-2 font-figtree focus:ring-0 focus:border-b-2 focus:border-pry border-pry border-0 w-full",
                        placeholder: "Email Address"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                        className: "px-3",
                        children: "Email address or application link is required"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                    name: "description",
                    required: true,
                    value: formValues.description,
                    onChange: handleChange,
                    className: "border-b-2 font-figtree focus:ring-0 focus:border-b-2 focus:border-pry border-pry border-0 w-full",
                    placeholder: "Job description",
                    rows: 5
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Index);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;