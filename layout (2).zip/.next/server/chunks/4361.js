"use strict";
exports.id = 4361;
exports.ids = [4361];
exports.modules = {

/***/ 4361:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Admin)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_Sidebar_Sidebar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2275);
/* harmony import */ var _components_DashboardHeader_DashboardHeader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5316);
/* harmony import */ var _heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(467);
/* harmony import */ var _fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7197);
/* harmony import */ var _fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4563);
/* harmony import */ var _lib_user__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3460);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Sidebar_Sidebar__WEBPACK_IMPORTED_MODULE_2__, _components_DashboardHeader_DashboardHeader__WEBPACK_IMPORTED_MODULE_3__, _heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_4__, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_6__, _lib_user__WEBPACK_IMPORTED_MODULE_7__]);
([_components_Sidebar_Sidebar__WEBPACK_IMPORTED_MODULE_2__, _components_DashboardHeader_DashboardHeader__WEBPACK_IMPORTED_MODULE_3__, _heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_4__, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_6__, _lib_user__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const user = {
    name: "Tom Cook",
    email: "tom@example.com",
    imageUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
};
const navigation = [
    {
        name: "Overview",
        href: "/admin",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_5__.FontAwesomeIcon, {
            icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_6__.faHomeAlt
        }),
        current: true
    },
    {
        name: "Members",
        href: "/admin/members",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_5__.FontAwesomeIcon, {
            icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_6__.faUserGroup
        }),
        current: true
    },
    {
        name: "Payments and Subscription",
        href: "/admin/payments",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_5__.FontAwesomeIcon, {
            icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_6__.faMoneyCheckDollar
        }),
        current: true
    },
    {
        name: "Events",
        href: "/admin/events",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_5__.FontAwesomeIcon, {
            icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_6__.faCalendarDays
        }),
        current: true
    },
    {
        name: "News and Updates",
        href: "/admin/news",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_5__.FontAwesomeIcon, {
            icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_6__.faNewspaper
        }),
        current: true
    },
    {
        name: "Job Board",
        href: "/admin/job-board",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_5__.FontAwesomeIcon, {
            icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_6__.faUserDoctor
        }),
        current: true
    }, 
];
const userNavigation = [];
function Admin({ children  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_lib_user__WEBPACK_IMPORTED_MODULE_7__/* .UserProvider */ .d, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "relative",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Sidebar_Sidebar__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    navigation: navigation,
                    userNavigation: userNavigation,
                    logo: "/logo.png"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "sidebar bg-gray-100 min-h-screen col-span-9 bg-blueGray-100",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_DashboardHeader_DashboardHeader__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                            userNavigation: userNavigation,
                            navigation: navigation
                        }),
                        children
                    ]
                })
            ]
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;